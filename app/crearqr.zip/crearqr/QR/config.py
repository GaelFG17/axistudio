DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "example",
    "database": "mydatabase"
}
